import 'package:flutter_test/flutter_test.dart';
import 'package:deplo_hatch_egg_sort/models/level_model.dart';

void main() {
  group('Game level configuration', () {
    test('contains four ordered levels', () {
      expect(gameLevels, hasLength(4));
      expect(gameLevels.map((level) => level.number), [1, 2, 3, 4]);
    });

    test('each level has three unique egg types', () {
      for (final level in gameLevels) {
        expect(level.eggTypes, hasLength(3));
        expect(level.eggTypes.map((egg) => egg.id).toSet(), hasLength(3));
      }
    });

    test('every level has animal and hatch sound metadata', () {
      for (final level in gameLevels) {
        expect(level.animalName, isNotEmpty);
        expect(level.animalEmoji, isNotEmpty);
        expect(level.hatchSound, startsWith('audio/'));
      }
    });
  });
}

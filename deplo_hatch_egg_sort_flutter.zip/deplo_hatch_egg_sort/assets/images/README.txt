Add your transparent PNG egg and animal images here.
The current game draws eggs with Flutter shapes and uses emoji for baby animals.
To switch to image assets, see README.md for the replacement steps.

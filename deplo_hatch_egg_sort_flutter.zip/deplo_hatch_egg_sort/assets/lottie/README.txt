Optional Lottie JSON animations can be placed here.
The current hatch sequence is built with Flutter animations and confetti.

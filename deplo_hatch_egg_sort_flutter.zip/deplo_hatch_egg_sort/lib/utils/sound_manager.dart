import 'package:audioplayers/audioplayers.dart';

class SoundManager {
  SoundManager._();
  static final SoundManager instance = SoundManager._();

  final AudioPlayer _effects = AudioPlayer();
  final AudioPlayer _music = AudioPlayer();

  bool muted = false;
  bool musicEnabled = true;

  Future<void> init() async {
    await _effects.setReleaseMode(ReleaseMode.stop);
    await _music.setReleaseMode(ReleaseMode.loop);
    await _music.setVolume(0.35);
  }

  Future<void> play(String asset) async {
    if (muted) return;
    try {
      await _effects.stop();
      await _effects.play(AssetSource(asset));
    } catch (_) {
      // Sound files are optional placeholders. Add the matching file to assets/audio.
    }
  }

  Future<void> startMusic(String asset) async {
    await stopMusic();
    if (!musicEnabled) return;
    try {
      await _music.play(AssetSource(asset));
    } catch (_) {
      // Music is optional until you add your own audio files.
    }
  }

  Future<void> stopMusic() async {
    try {
      await _music.stop();
    } catch (_) {}
  }

  Future<void> setMuted(bool value) async {
    // This toggle controls sound effects only; background music has its own switch.
    muted = value;
  }

  Future<void> setMusicEnabled(bool value, {String? currentTrack}) async {
    musicEnabled = value;
    if (value && !muted && currentTrack != null) {
      await startMusic(currentTrack);
    } else {
      await stopMusic();
    }
  }

  Future<void> dispose() async {
    await _effects.dispose();
    await _music.dispose();
  }
}

import 'package:flutter/material.dart';

class EggType {
  final String id;
  final String label;
  final Color color;
  final String imageAsset;

  const EggType({
    required this.id,
    required this.label,
    required this.color,
    required this.imageAsset,
  });
}

class LevelModel {
  final int number;
  final String title;
  final String subtitle;
  final String icon;
  final Color accent;
  final List<Color> background;
  final String backgroundLabel;
  final String animalName;
  final String animalEmoji;
  final String hatchSound;
  final String music;
  final List<EggType> eggTypes;
  final String specialNote;

  const LevelModel({
    required this.number,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.accent,
    required this.background,
    required this.backgroundLabel,
    required this.animalName,
    required this.animalEmoji,
    required this.hatchSound,
    required this.music,
    required this.eggTypes,
    this.specialNote = '',
  });
}

const List<LevelModel> gameLevels = [
  LevelModel(
    number: 1,
    title: 'Sunny Farm',
    subtitle: 'Meet the baby chick',
    icon: '🐥',
    accent: Color(0xFF65BD62),
    background: [Color(0xFF9DE6A0), Color(0xFFDFF6A8), Color(0xFFFFE5A3)],
    backgroundLabel: 'FARM',
    animalName: 'Baby Chick',
    animalEmoji: '🐥',
    hatchSound: 'audio/chick.mp3',
    music: 'audio/farm_music.mp3',
    eggTypes: [
      EggType(id: 'white', label: 'White', color: Color(0xFFFFFEF4), imageAsset: 'assets/images/egg_white.png'),
      EggType(id: 'brown', label: 'Brown', color: Color(0xFFB87945), imageAsset: 'assets/images/egg_brown.png'),
      EggType(id: 'yellow', label: 'Yellow', color: Color(0xFFFFD95A), imageAsset: 'assets/images/egg_yellow.png'),
    ],
  ),
  LevelModel(
    number: 2,
    title: 'Forest Falls',
    subtitle: 'A colourful baby peacock',
    icon: '🦚',
    accent: Color(0xFF27A99A),
    background: [Color(0xFF76D9B4), Color(0xFFB9E8A5), Color(0xFFDAF5D0)],
    backgroundLabel: 'FOREST',
    animalName: 'Baby Peacock',
    animalEmoji: '🦚',
    hatchSound: 'audio/peacock.mp3',
    music: 'audio/forest_music.mp3',
    eggTypes: [
      EggType(id: 'blue', label: 'Blue', color: Color(0xFF438EEB), imageAsset: 'assets/images/egg_blue.png'),
      EggType(id: 'green', label: 'Green', color: Color(0xFF50B96B), imageAsset: 'assets/images/egg_green.png'),
      EggType(id: 'teal', label: 'Teal', color: Color(0xFF28B9B0), imageAsset: 'assets/images/egg_teal.png'),
    ],
    specialNote: 'The little peacock fans out its feathers!',
  ),
  LevelModel(
    number: 3,
    title: 'Icy Adventure',
    subtitle: 'Help a penguin hatch',
    icon: '🐧',
    accent: Color(0xFF55B9E9),
    background: [Color(0xFF8DDCFF), Color(0xFFD6F3FF), Color(0xFFF4FCFF)],
    backgroundLabel: 'ICE WORLD',
    animalName: 'Baby Penguin',
    animalEmoji: '🐧',
    hatchSound: 'audio/penguin.mp3',
    music: 'audio/winter_music.mp3',
    eggTypes: [
      EggType(id: 'snow', label: 'Snow White', color: Color(0xFFFFFEF7), imageAsset: 'assets/images/egg_white.png'),
      EggType(id: 'ice', label: 'Ice Blue', color: Color(0xFFB8E8FF), imageAsset: 'assets/images/egg_ice_blue.png'),
      EggType(id: 'sky', label: 'Sky Blue', color: Color(0xFF65B9F2), imageAsset: 'assets/images/egg_sky_blue.png'),
    ],
  ),
  LevelModel(
    number: 4,
    title: 'Dragon Volcano',
    subtitle: 'The little boss-level dragon',
    icon: '🐉',
    accent: Color(0xFFED7548),
    background: [Color(0xFF6E3441), Color(0xFFB94D38), Color(0xFFFFA34D)],
    backgroundLabel: 'VOLCANO',
    animalName: 'Baby Dragon',
    animalEmoji: '🐉',
    hatchSound: 'audio/dragon.mp3',
    music: 'audio/dragon_music.mp3',
    eggTypes: [
      EggType(id: 'red', label: 'Red', color: Color(0xFFE94C4C), imageAsset: 'assets/images/egg_red.png'),
      EggType(id: 'orange', label: 'Orange', color: Color(0xFFFF9D35), imageAsset: 'assets/images/egg_orange.png'),
      EggType(id: 'black', label: 'Black', color: Color(0xFF34313C), imageAsset: 'assets/images/egg_black.png'),
    ],
    specialNote: 'A tiny fire-breathing dragon is waiting!',
  ),
];

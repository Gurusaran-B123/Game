import 'dart:async';
import 'package:flutter/material.dart';
import '../models/level_model.dart';
import '../utils/sound_manager.dart';
import '../widgets/egg_widget.dart';
import '../widgets/hatch_animation.dart';
import '../widgets/nest_widget.dart';

class GameScreen extends StatefulWidget {
  final LevelModel level;
  const GameScreen({super.key, required this.level});

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> with TickerProviderStateMixin {
  late List<int> _counts;
  late List<EggType> _eggs;
  late List<bool> _hatched;
  late int _seconds;
  int _score = 0;
  int? _wrongEggIndex;
  bool _showWrongMessage = false;
  int? _hatchingIndex;
  bool _paused = false;
  bool _gameOver = false;
  bool _complete = false;
  bool _settingsOpen = false;
  Timer? _timer;
  late final AnimationController _backgroundController;

  @override
  void initState() {
    super.initState();
    _counts = List.filled(widget.level.eggTypes.length, 0);
    _hatched = List.filled(widget.level.eggTypes.length, false);
    _seconds = 90;
    _eggs = [];
    for (final type in widget.level.eggTypes) {
      _eggs.addAll(List.filled(3, type));
    }
    _eggs.shuffle();
    _backgroundController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 12),
    )..repeat();
    _startTimer();
    SoundManager.instance.startMusic(widget.level.music);
  }

  void _startTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted || _paused || _hatchingIndex != null || _complete || _gameOver) return;
      setState(() {
        _seconds--;
        if (_seconds <= 0) {
          _seconds = 0;
          _gameOver = true;
          _timer?.cancel();
          SoundManager.instance.stopMusic();
        }
      });
    });
  }

  void _onEggDropped(EggType egg, int nestIndex) {
    if (_paused || _gameOver || _complete || _hatched[nestIndex]) return;
    if (egg.id != widget.level.eggTypes[nestIndex].id) {
      setState(() {
        _wrongEggIndex = _eggs.indexOf(egg);
        _showWrongMessage = true;
      });
      SoundManager.instance.play('audio/wrong.mp3');
      Future.delayed(const Duration(milliseconds: 850), () {
        if (mounted) {
          setState(() {
            _wrongEggIndex = null;
            _showWrongMessage = false;
          });
        }
      });
      return;
    }

    setState(() {
      _eggs.remove(egg);
      _counts[nestIndex]++;
      _score += 10;
    });
    SoundManager.instance.play('audio/pop.mp3');

    if (_counts[nestIndex] == 3) {
      _triggerHatch(nestIndex);
    }
  }

  Future<void> _triggerHatch(int index) async {
    setState(() => _hatchingIndex = index);
    await Future.delayed(const Duration(milliseconds: 1700));
    if (!mounted) return;
    setState(() {
      _hatched[index] = true;
      _hatchingIndex = null;
      _score += 100;
    });
    SoundManager.instance.play(widget.level.hatchSound);
    if (_hatched.every((value) => value)) {
      _timer?.cancel();
      await SoundManager.instance.stopMusic();
      await Future.delayed(const Duration(milliseconds: 500));
      if (mounted) setState(() => _complete = true);
    }
  }

  void _togglePause() {
    setState(() => _paused = !_paused);
    if (_paused) {
      SoundManager.instance.stopMusic();
      _showPauseDialog();
    } else {
      SoundManager.instance.startMusic(widget.level.music);
    }
  }

  Future<void> _showPauseDialog() async {
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: const Text('⏸️ Game Paused',
            textAlign: TextAlign.center,
            style: TextStyle(fontWeight: FontWeight.w900)),
        content: const Text('Take a little break, hatchling helper!',
            textAlign: TextAlign.center),
        actionsAlignment: MainAxisAlignment.center,
        actions: [
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Continue'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(dialogContext);
              Navigator.pop(context);
            },
            child: const Text('Exit level'),
          ),
        ],
      ),
    );
    if (mounted && !_complete && !_gameOver) {
      setState(() => _paused = false);
      SoundManager.instance.startMusic(widget.level.music);
    }
  }

  void _showSettings() {
    final sound = SoundManager.instance;
    showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          title: const Text('⚙️ Settings',
              style: TextStyle(fontWeight: FontWeight.w900)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Sound effects'),
                value: !sound.muted,
                onChanged: (value) async {
                  await sound.setMuted(!value);
                  setDialogState(() {});
                },
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Background music'),
                value: sound.musicEnabled,
                onChanged: (value) async {
                  await sound.setMusicEnabled(value,
                      currentTrack: widget.level.music);
                  setDialogState(() {});
                },
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Done'),
            ),
          ],
        ),
      ),
    );
  }

  void _retry() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => GameScreen(level: widget.level)),
    );
  }

  void _nextLevel() {
    if (widget.level.number >= gameLevels.length) {
      Navigator.pop(context);
      return;
    }
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => GameScreen(level: gameLevels[widget.level.number]),
      ),
    );
  }

  String get _timeText {
    final minutes = (_seconds ~/ 60).toString().padLeft(2, '0');
    final seconds = (_seconds % 60).toString().padLeft(2, '0');
    return '$minutes:$seconds';
  }

  @override
  void dispose() {
    _timer?.cancel();
    _backgroundController.dispose();
    SoundManager.instance.stopMusic();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final level = widget.level;
    return Scaffold(
      body: Stack(
        children: [
          AnimatedBuilder(
            animation: _backgroundController,
            builder: (context, _) => Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  transform: GradientRotation(_backgroundController.value * 0.12),
                  colors: level.background,
                ),
              ),
              child: CustomPaint(
                painter: _ScenePainter(levelNumber: level.number),
                child: const SizedBox.expand(),
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                _buildTopBar(),
                Padding(
                  padding: const EdgeInsets.fromLTRB(14, 5, 14, 7),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          'Match each egg to its nest!',
                          style: TextStyle(
                            color: level.number == 4 ? Colors.white : const Color(0xFF355D43),
                            fontWeight: FontWeight.w900,
                            fontSize: 15,
                            shadows: level.number == 4
                                ? [const Shadow(color: Colors.black54, blurRadius: 4)]
                                : null,
                          ),
                        ),
                      ),
                      if (level.specialNote.isNotEmpty)
                        Flexible(
                          child: Text(level.specialNote,
                              textAlign: TextAlign.end,
                              style: TextStyle(
                                fontSize: 10,
                                color: level.number == 4 ? Colors.white : const Color(0xFF486B50),
                                fontWeight: FontWeight.w700,
                              )),
                        ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 13),
                  child: Row(
                    children: List.generate(level.eggTypes.length, (index) {
                      final egg = level.eggTypes[index];
                      return Expanded(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 4),
                          child: DragTarget<EggType>(
                            onWillAcceptWithDetails: (details) =>
                                !_paused && !_hatched[index] && !_complete && !_gameOver,
                            onAcceptWithDetails: (details) =>
                                _onEggDropped(details.data, index),
                            builder: (context, candidate, rejected) {
                              return NestWidget(
                                egg: egg,
                                count: _counts[index],
                                hatched: _hatched[index],
                                animalEmoji: level.animalEmoji,
                                isTarget: candidate.isNotEmpty,
                              );
                            },
                          ),
                        ),
                      );
                    }),
                  ),
                ),
                const SizedBox(height: 10),
                Expanded(
                  child: Container(
                    margin: const EdgeInsets.fromLTRB(12, 0, 12, 9),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.35),
                      borderRadius: BorderRadius.circular(25),
                      border: Border.all(color: Colors.white.withValues(alpha: 0.55)),
                    ),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            const Text('EGG BASKET',
                                style: TextStyle(
                                  color: Color(0xFF49634D),
                                  fontWeight: FontWeight.w900,
                                  fontSize: 11,
                                  letterSpacing: 1.2,
                                )),
                            const Spacer(),
                            Text('${_eggs.length} eggs left',
                                style: const TextStyle(
                                    color: Color(0xFF637A63),
                                    fontWeight: FontWeight.bold,
                                    fontSize: 11)),
                          ],
                        ),
                        const SizedBox(height: 9),
                        Expanded(
                          child: _eggs.isEmpty
                              ? Center(
                                  child: Text(
                                    _hatched.every((v) => v)
                                        ? 'All little friends are home! 🏡'
                                        : 'Great sorting! Watch them hatch…',
                                    textAlign: TextAlign.center,
                                    style: const TextStyle(
                                      fontSize: 17,
                                      fontWeight: FontWeight.w900,
                                      color: Color(0xFF3F754C),
                                    ),
                                  ),
                                )
                              : GridView.builder(
                                  physics: const NeverScrollableScrollPhysics(),
                                  itemCount: _eggs.length,
                                  gridDelegate:
                                      const SliverGridDelegateWithFixedCrossAxisCount(
                                    crossAxisCount: 5,
                                    mainAxisSpacing: 8,
                                    crossAxisSpacing: 4,
                                    childAspectRatio: 0.62,
                                  ),
                                  itemBuilder: (context, index) {
                                    final egg = _eggs[index];
                                    final eggKey = ValueKey('${egg.id}-$index-${_eggs.length}');
                                    return Center(
                                      child: Draggable<EggType>(
                                        data: egg,
                                        maxSimultaneousDrags:
                                            _paused || _complete || _gameOver ? 0 : 1,
                                        feedback: Material(
                                          color: Colors.transparent,
                                          child: EggWidget(egg: egg),
                                        ),
                                        childWhenDragging: Opacity(
                                          opacity: 0.2,
                                          child: EggWidget(egg: egg),
                                        ),
                                        onDragCompleted: () {},
                                        child: AnimatedScale(
                                          key: eggKey,
                                          scale: 1,
                                          duration: const Duration(milliseconds: 160),
                                          child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              EggWidget(egg: egg,
                                                  shaking: _wrongEggIndex == index),
                                              const SizedBox(height: 3),
                                              Text(egg.label,
                                                  style: const TextStyle(
                                                    fontSize: 9,
                                                    fontWeight: FontWeight.w800,
                                                    color: Color(0xFF566C58),
                                                  )),
                                            ],
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                ),
                        ),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(14, 0, 14, 10),
                  child: Row(
                    children: [
                      Text('🏡 ${level.backgroundLabel}',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w900,
                            color: level.number == 4 ? Colors.white : const Color(0xFF4A684D),
                          )),
                      const Spacer(),
                      Text('Hatch all 3 friends!',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                            color: level.number == 4 ? Colors.white : const Color(0xFF4A684D),
                          )),
                    ],
                  ),
                ),
              ],
            ),
          ),
          if (_showWrongMessage)
            Positioned(
              left: 0,
              right: 0,
              bottom: 92,
              child: Center(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 10),
                  decoration: BoxDecoration(
                    color: const Color(0xFFE85C55),
                    borderRadius: BorderRadius.circular(30),
                    boxShadow: const [
                      BoxShadow(color: Colors.black26, blurRadius: 10, offset: Offset(0, 4))
                    ],
                  ),
                  child: const Text('Wrong! Try the matching nest.',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                        fontSize: 14,
                      )),
                ),
              ),
            ),
          if (_hatchingIndex != null)
            Positioned.fill(
              child: ColoredBox(
                color: Colors.black.withValues(alpha: 0.12),
                child: Center(
                  child: Container(
                    width: 220,
                    padding: const EdgeInsets.all(15),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.94),
                      borderRadius: BorderRadius.circular(25),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        HatchAnimation(
                          key: ValueKey('hatch-$_hatchingIndex'),
                          animalEmoji: level.animalEmoji,
                          onFinished: () {},
                        ),
                        Text('A ${level.animalName}!',
                            style: const TextStyle(
                              fontWeight: FontWeight.w900,
                              fontSize: 17,
                              color: Color(0xFF3E784C),
                            )),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          if (_paused || _gameOver || _complete)
            Positioned.fill(
              child: ColoredBox(
                color: Colors.black.withValues(alpha: 0.45),
                child: Center(
                  child: _gameOver
                      ? _resultCard(
                          title: 'Time is up!',
                          subtitle: 'Your little friends are still waiting.',
                          emoji: '⏰',
                          buttonText: 'Retry',
                          onPressed: _retry,
                          secondaryText: 'Level Select',
                          onSecondary: () => Navigator.pop(context),
                        )
                      : _complete
                          ? _resultCard(
                              title: 'Level Complete!',
                              subtitle: 'You hatched every little friend!',
                              emoji: '🎉',
                              buttonText: widget.level.number == 4
                                  ? 'Finish Game'
                                  : 'Next Level',
                              onPressed: _nextLevel,
                              stars: _seconds >= 55 ? 3 : (_seconds >= 25 ? 2 : 1),
                            )
                          : const SizedBox.shrink(),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildTopBar() {
    final lightText = widget.level.number == 4;
    final color = lightText ? Colors.white : const Color(0xFF355D43);
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 5),
      child: Row(
        children: [
          IconButton.filledTonal(
            tooltip: 'Back',
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.arrow_back_rounded),
          ),
          const SizedBox(width: 4),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('LEVEL ${widget.level.number}',
                    style: TextStyle(
                        color: color,
                        fontSize: 10,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.2)),
                Text(widget.level.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        color: color, fontSize: 17, fontWeight: FontWeight.w900)),
              ],
            ),
          ),
          _statChip('⭐', '$_score'),
          const SizedBox(width: 5),
          _statChip('⏱', _timeText),
          const SizedBox(width: 3),
          IconButton(
            tooltip: 'Settings',
            onPressed: _showSettings,
            icon: Icon(Icons.settings_rounded, color: color),
          ),
          IconButton(
            tooltip: 'Pause',
            onPressed: _togglePause,
            icon: Icon(Icons.pause_circle_filled_rounded, color: color, size: 30),
          ),
        ],
      ),
    );
  }

  Widget _statChip(String emoji, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.78),
        borderRadius: BorderRadius.circular(13),
      ),
      child: Text('$emoji $value',
          style: const TextStyle(
              fontSize: 11, fontWeight: FontWeight.w900, color: Color(0xFF3E5B43))),
    );
  }

  Widget _resultCard({
    required String title,
    required String subtitle,
    required String emoji,
    required String buttonText,
    required VoidCallback onPressed,
    String? secondaryText,
    VoidCallback? onSecondary,
    int? stars,
  }) {
    return Container(
      margin: const EdgeInsets.all(28),
      padding: const EdgeInsets.fromLTRB(22, 24, 22, 20),
      decoration: BoxDecoration(
        color: const Color(0xFFFFFDF5),
        borderRadius: BorderRadius.circular(30),
        boxShadow: const [
          BoxShadow(color: Colors.black26, blurRadius: 20, offset: Offset(0, 8))
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(emoji, style: const TextStyle(fontSize: 58)),
          Text(title,
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontSize: 25,
                  fontWeight: FontWeight.w900,
                  color: Color(0xFF3B754B))),
          if (stars != null) ...[
            const SizedBox(height: 5),
            Text('⭐' * stars + '☆' * (3 - stars),
                style: const TextStyle(fontSize: 30)),
          ],
          const SizedBox(height: 7),
          Text(subtitle,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Color(0xFF718071), fontSize: 13)),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFF55B96B),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
              ),
              onPressed: onPressed,
              child: Text(buttonText,
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.w900)),
            ),
          ),
          if (secondaryText != null)
            TextButton(
              onPressed: onSecondary,
              child: Text(secondaryText),
            ),
        ],
      ),
    );
  }
}

class _ScenePainter extends CustomPainter {
  final int levelNumber;
  _ScenePainter({required this.levelNumber});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..style = PaintingStyle.fill;
    if (levelNumber == 1) {
      paint.color = const Color(0xFF64B95E).withValues(alpha: 0.25);
      canvas.drawOval(Rect.fromLTWH(-30, size.height * .58, size.width * .7, size.height * .5), paint);
      canvas.drawOval(Rect.fromLTWH(size.width * .45, size.height * .62, size.width * .7, size.height * .5), paint);
      paint.color = const Color(0xFFFFD35D).withValues(alpha: .7);
      canvas.drawCircle(Offset(size.width - 45, 45), 25, paint);
      paint.color = const Color(0xFF9D7049).withValues(alpha: .5);
      canvas.drawRect(Rect.fromLTWH(size.width * .08, size.height * .38, 48, 35), paint);
      final roof = Path()
        ..moveTo(size.width * .06, size.height * .38)
        ..lineTo(size.width * .12, size.height * .32)
        ..lineTo(size.width * .19, size.height * .38)
        ..close();
      canvas.drawPath(roof, paint);
    } else if (levelNumber == 2) {
      paint.color = const Color(0xFF278D61).withValues(alpha: .25);
      for (int i = 0; i < 6; i++) {
        canvas.drawCircle(Offset((i * 83.0) % size.width, size.height * .55), 28, paint);
        canvas.drawRect(Rect.fromLTWH((i * 83.0) % size.width - 3, size.height * .55, 6, 85), paint);
      }
      paint.color = Colors.white.withValues(alpha: .4);
      canvas.drawRRect(RRect.fromRectAndRadius(
        Rect.fromLTWH(size.width * .78, size.height * .34, 24, size.height * .25),
        const Radius.circular(12)), paint);
    } else if (levelNumber == 3) {
      paint.color = Colors.white.withValues(alpha: .55);
      for (int i = 0; i < 28; i++) {
        final x = (i * 47.0) % size.width;
        final y = (i * 71.0) % (size.height * .72);
        canvas.drawCircle(Offset(x, y), i % 3 == 0 ? 3 : 1.8, paint);
      }
      paint.color = const Color(0xFF70BCE5).withValues(alpha: .3);
      canvas.drawRRect(RRect.fromRectAndRadius(
        Rect.fromLTWH(size.width * .08, size.height * .66, 82, 48),
        const Radius.circular(24)), paint);
    } else {
      paint.color = const Color(0xFFFFB23F).withValues(alpha: .25);
      final lava = Path()
        ..moveTo(0, size.height * .72)
        ..quadraticBezierTo(size.width * .2, size.height * .62, size.width * .4, size.height * .73)
        ..quadraticBezierTo(size.width * .7, size.height * .82, size.width, size.height * .68)
        ..lineTo(size.width, size.height)
        ..lineTo(0, size.height)
        ..close();
      canvas.drawPath(lava, paint);
      paint.color = const Color(0xFFFFD15A).withValues(alpha: .7);
      canvas.drawCircle(Offset(size.width * .84, size.height * .25), 5, paint);
      canvas.drawCircle(Offset(size.width * .2, size.height * .5), 4, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _ScenePainter oldDelegate) =>
      oldDelegate.levelNumber != levelNumber;
}

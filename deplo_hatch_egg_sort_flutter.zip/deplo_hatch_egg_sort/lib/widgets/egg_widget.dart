import 'package:flutter/material.dart';
import '../models/level_model.dart';

class EggWidget extends StatefulWidget {
  final EggType egg;
  final bool compact;
  final bool shaking;

  const EggWidget({
    super.key,
    required this.egg,
    this.compact = false,
    this.shaking = false,
  });

  @override
  State<EggWidget> createState() => _EggWidgetState();
}

class _EggWidgetState extends State<EggWidget>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _shake;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 420),
    );
    _shake = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 0, end: -0.12), weight: 1),
      TweenSequenceItem(tween: Tween(begin: -0.12, end: 0.12), weight: 2),
      TweenSequenceItem(tween: Tween(begin: 0.12, end: -0.08), weight: 2),
      TweenSequenceItem(tween: Tween(begin: -0.08, end: 0), weight: 1),
    ]).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
    if (widget.shaking) _controller.repeat();
  }

  @override
  void didUpdateWidget(covariant EggWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.shaking && !oldWidget.shaking) {
      _controller.repeat();
    } else if (!widget.shaking && oldWidget.shaking) {
      _controller.stop();
      _controller.value = 0;
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final width = widget.compact ? 18.0 : 46.0;
    return AnimatedBuilder(
      animation: _shake,
      builder: (context, child) => Transform.rotate(
        angle: _shake.value,
        child: child,
      ),
      child: Container(
        width: width,
        height: width * 1.27,
        decoration: BoxDecoration(
          color: widget.egg.color,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(width * 0.48),
            topRight: Radius.circular(width * 0.48),
            bottomLeft: Radius.circular(width * 0.43),
            bottomRight: Radius.circular(width * 0.43),
          ),
          border: Border.all(color: Colors.black.withValues(alpha: 0.10), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.15),
              blurRadius: 5,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Stack(
          children: [
            Positioned(
              left: width * 0.18,
              top: width * 0.22,
              child: Container(
                width: width * 0.18,
                height: width * 0.36,
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.48),
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
            ),
            if (widget.egg.id == 'black')
              Center(
                child: Icon(Icons.auto_awesome,
                    color: Colors.white.withValues(alpha: 0.6), size: 15),
              ),
          ],
        ),
      ),
    );
  }
}

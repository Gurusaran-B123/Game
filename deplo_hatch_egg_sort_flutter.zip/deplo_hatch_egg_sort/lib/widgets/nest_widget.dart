import 'package:flutter/material.dart';
import '../models/level_model.dart';
import 'egg_widget.dart';

class NestWidget extends StatelessWidget {
  final EggType egg;
  final int count;
  final bool hatched;
  final String animalEmoji;
  final bool isTarget;

  const NestWidget({
    super.key,
    required this.egg,
    required this.count,
    required this.hatched,
    required this.animalEmoji,
    this.isTarget = false,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      padding: const EdgeInsets.fromLTRB(8, 9, 8, 7),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: isTarget ? 0.92 : 0.72),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: isTarget ? egg.color : Colors.white.withValues(alpha: 0.8),
          width: isTarget ? 3 : 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.10),
            blurRadius: 9,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(egg.label.toUpperCase(),
              style: const TextStyle(
                fontSize: 9,
                fontWeight: FontWeight.w900,
                letterSpacing: 0.6,
                color: Color(0xFF536252),
              )),
          const SizedBox(height: 5),
          Container(
            height: 64,
            width: double.infinity,
            decoration: BoxDecoration(
              color: const Color(0xFFB98253).withValues(alpha: 0.25),
              borderRadius: BorderRadius.circular(15),
              border: Border.all(
                  color: const Color(0xFF9A673F).withValues(alpha: 0.35)),
            ),
            child: Center(
              child: hatched
                  ? Text(animalEmoji, style: const TextStyle(fontSize: 39))
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(
                        3,
                        (i) => Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 2),
                          child: i < count
                              ? EggWidget(egg: egg, compact: true)
                              : Icon(Icons.circle_outlined,
                                  size: 19,
                                  color: egg.color.withValues(alpha: 0.75)),
                        ),
                      ),
                    ),
            ),
          ),
          const SizedBox(height: 5),
          Text(hatched ? 'HATCHED!' : '$count / 3 EGGS',
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w900,
                color: hatched ? const Color(0xFF399B5A) : const Color(0xFF6B796A),
              )),
        ],
      ),
    );
  }
}

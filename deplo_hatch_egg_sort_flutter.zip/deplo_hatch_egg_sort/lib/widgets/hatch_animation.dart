import 'package:confetti/confetti.dart';
import 'package:lottie/lottie.dart';
import 'package:flutter/material.dart';
import 'dart:math' as math;

class HatchAnimation extends StatefulWidget {
  final String animalEmoji;
  final VoidCallback onFinished;

  const HatchAnimation({
    super.key,
    required this.animalEmoji,
    required this.onFinished,
  });

  @override
  State<HatchAnimation> createState() => _HatchAnimationState();
}

class _HatchAnimationState extends State<HatchAnimation>
    with TickerProviderStateMixin {
  late final AnimationController _controller;
  late final ConfettiController _confetti;
  bool _finished = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1900),
    )..forward();
    _confetti = ConfettiController(duration: const Duration(milliseconds: 1500));
    Future.delayed(const Duration(milliseconds: 850), () {
      if (mounted) _confetti.play();
    });
    _controller.addStatusListener((status) {
      if (status == AnimationStatus.completed && !_finished) {
        _finished = true;
        widget.onFinished();
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _confetti.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 120,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Replace this lightweight Lottie placeholder with your own hatch animation.
          Lottie.asset(
            'assets/lottie/hatch_sparkle.json',
            width: 150,
            height: 150,
            repeat: false,
          ),
          ConfettiWidget(
            confettiController: _confetti,
            blastDirectionality: BlastDirectionality.explosive,
            shouldLoop: false,
            numberOfParticles: 18,
            maxBlastForce: 18,
            minBlastForce: 7,
            gravity: 0.25,
            emissionFrequency: 0.05,
          ),
          AnimatedBuilder(
            animation: _controller,
            builder: (context, _) {
              final t = _controller.value;
              final shake = t < 0.48 ? math.sin(t * 24) * 5 : 0.0;
              final scale = t < 0.48
                  ? 1.0
                  : (0.55 + (Curves.elasticOut.transform(
                      ((t - 0.48) / 0.52).clamp(0.0, 1.0)) * 0.55));
              return Transform.translate(
                offset: Offset(shake, t < 0.48 ? 0 : -12 * (1 - t)),
                child: Transform.scale(
                  scale: scale,
                  child: Text(
                    t < 0.56 ? '🥚' : widget.animalEmoji,
                    style: const TextStyle(fontSize: 66),
                  ),
                ),
              );
            },
          ),
          if (_controller.value >= 0.42 && _controller.value < 0.75)
            const Positioned(
              top: 4,
              child: Text('✦  ╱╲  ✦',
                  style: TextStyle(fontSize: 24, color: Colors.white)),
            ),
        ],
      ),
    );
  }
}


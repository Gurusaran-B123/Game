import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'models/level_model.dart';
import 'screens/game_screen.dart';
import 'utils/sound_manager.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
  ]);
  await SoundManager.instance.init();
  runApp(const DeploHatchApp());
}

class DeploHatchApp extends StatelessWidget {
  const DeploHatchApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Deplo Hatch - Egg Sort',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Trebuchet MS',
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF55B96B)),
        scaffoldBackgroundColor: const Color(0xFFFFF8E9),
      ),
      home: const LevelSelectScreen(),
    );
  }
}

class LevelSelectScreen extends StatelessWidget {
  const LevelSelectScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFB8F0FF), Color(0xFFFFF3C5), Color(0xFFFFD9A8)],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(22),
              child: Column(
                children: [
                  const SizedBox(height: 12),
                  const Text('🥚', style: TextStyle(fontSize: 72)),
                  const Text(
                    'DEPLO HATCH',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.5,
                      color: Color(0xFF315B43),
                    ),
                  ),
                  const Text(
                    'EGG SORT',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 5,
                      color: Color(0xFFDF8A36),
                    ),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'Match the eggs, hatch the little friends!',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 16, color: Color(0xFF536B58)),
                  ),
                  const SizedBox(height: 28),
                  ...List.generate(gameLevels.length, (index) {
                    final level = gameLevels[index];
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 13),
                      child: Material(
                        color: Colors.white.withValues(alpha: 0.92),
                        borderRadius: BorderRadius.circular(22),
                        elevation: 3,
                        child: InkWell(
                          borderRadius: BorderRadius.circular(22),
                          onTap: () => Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => GameScreen(level: level),
                            ),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 18,
                              vertical: 16,
                            ),
                            child: Row(
                              children: [
                                Container(
                                  width: 54,
                                  height: 54,
                                  decoration: BoxDecoration(
                                    color: level.accent.withValues(alpha: 0.16),
                                    borderRadius: BorderRadius.circular(17),
                                  ),
                                  alignment: Alignment.center,
                                  child: Text(level.icon,
                                      style: const TextStyle(fontSize: 31)),
                                ),
                                const SizedBox(width: 14),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text('LEVEL ${level.number}',
                                          style: const TextStyle(
                                            color: Color(0xFF9A9A9A),
                                            fontWeight: FontWeight.bold,
                                            fontSize: 11,
                                            letterSpacing: 1.2,
                                          )),
                                      Text(level.title,
                                          style: const TextStyle(
                                            color: Color(0xFF304B39),
                                            fontSize: 18,
                                            fontWeight: FontWeight.w900,
                                          )),
                                      Text(level.subtitle,
                                          style: const TextStyle(
                                            color: Color(0xFF718071),
                                            fontSize: 12,
                                          )),
                                    ],
                                  ),
                                ),
                                const Icon(Icons.play_circle_fill_rounded,
                                    color: Color(0xFF58B86B), size: 34),
                              ],
                            ),
                          ),
                        ),
                      ),
                    );
                  }),
                  const SizedBox(height: 4),
                  const Text('Drag 3 matching eggs into each nest.',
                      style: TextStyle(
                          color: Color(0xFF6B806C),
                          fontWeight: FontWeight.w600)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
